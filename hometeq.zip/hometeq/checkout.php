<?php
//session_start();
include('db.php');
$pagename="Your Login Results"; //Create and populate a variable called $pagename
echo "<link rel=stylesheet type=text/css href=mystylesheet.css>"; //Call in stylesheet
echo "<title>".$pagename."</title>"; //display name of the page as window title
echo "<body>";
include ("headfile.html"); //include header layout file
include('detectlogin.php');
echo "<h4>".$pagename."</h4>"; //display name of the page on the web page

date_default_timezone_set('Asia/Colombo');
$dateTime = date('Y-m-d H:i:s');




//SQL SELECT query to retrieve max order number for current user (for which id matches the id in the session)
//to retrieve the order number of most recent order placed by current user
$sql = "INSERT INTO orders ( `userId`, `orderDateTime`, `orderTotal`) VALUES (".$_SESSION['userid'].",'$dateTime',1)";
//execute SQL query
mysqli_query($conn,$sql);
$maxId = "SELECT MAX(orderNo) as orderNo FROM orders where userId=".$_SESSION['userid'];
//fetch the result of the execution of the SQL statement and store it in an array arrayord
$arrayord = mysqli_query($conn,$maxId) or die(mysqli_error());
$maxOrderNo = mysqli_fetch_array($arrayord);
//store the value of this order number in a local variable

$maxOrderNo = $maxOrderNo['orderNo'];
//display message to confirm that order has been placed successfully and display the order number.
echo '<b>Successful Order</b> - ORDER REFERENCE NO:'.$maxOrderNo;
//as for basket.php, display a table header for product name, price, quantity and subtotal
echo "<table style='border: 0px'>";
	echo "<tr>";
	echo "<th>Product Name</td>";
	echo "<th>price</td>";
	echo "<th>Quantity</td>";
	echo "<th>Sub total</th>";
	$total=0;
//as for basket.php, FOREACH loop through basket session array & split value from index for every cell

	if(ISSET ($_SESSION['basket']))
{
	foreach ($_SESSION['basket'] as  $key => $value)
	{
//SQL query to retrieve product id, name and price from product table for every index in FOREACH loop
$SQL="select proId, prodName, prodPrice from Product where proId=".$key;
//execute SQL query, fetch the records and store them in an array of records $arrayb.
$exeSQL=mysqli_query($conn, $SQL) or die (mysqli_error());
$data=mysqli_fetch_array($exeSQL);		
//Calculate subtotal
echo "<tr>";
		echo "<td>".$data['prodName']."</td>";//display product name as contained in the array
		echo "<td>&pound;".$data['prodPrice']."</td>";
		echo "<td>".$value."</td>";
		$subTotal = $value*$data['prodPrice'];
		echo "<td>&pound;".$subTotal."</td>";

//Note: these 3 instructions are the same as in basket.php
//SQL INSERT query to store details of ordered items in Order_line table in the DB i.e. order number,
//product id (index), ordered quantity (content of the session array) and subtotal. Execute query.
//display the product name, price, ordered quantity and subtotal (same as for basket.php)
//increment total (same as for basket.php)

//create a new table row to display the total (same as for basket.php)
//SQL UPDATE query to update the total value in the order table for this specific order
//execute SQL query and display logout link.
}
//else i.e. if a database error is returned, display an order error message
{
//Display an error message that indicates that there has been an error with placing the order
}
//Unset the basket session array
//echo count($maxOrderNo);
		$product = "INSERT INTO `order_line` (`orderNo`, `prodId`, `quantityOrdered`, `subTotal`) VALUES
					($maxOrderNo,$key,$value,$subTotal)";
//		echo $product;
		mysqli_query($conn,$product) or die(mysqli_error($conn));
		$total = $total+$subTotal;
		echo "</tr>";
		
	}
}
echo "<tr>
			<th colspan=3 align='right'>Total</th>
			<th>&pound;$total</th>
			
		</tr>";
echo "</table>";

$update = "UPDATE orders SET orderTotal=$total WHERE userId=".$_SESSION['userid']." AND orderNo=$maxOrderNo";
mysqli_query($conn,$update);

include("footfile.html"); //include head layout
echo "</body>";
?>